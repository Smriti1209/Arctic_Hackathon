package com.leviabd.smpshome.model

data class Apartments(
    val id: Int,
    val name: String,
    val picture: String,
)