package com.leviabd.smpshome.model

data class Zones(
    val id: Int,
    val name: String,
)